package iss.java.mail;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeUtility;

import com.sun.mail.imap.IMAPFolder;
import com.sun.mail.imap.IMAPStore;

public class Main2014302580311 implements IMailService
{
private	Properties props;
private String user="zhongzhongbaby@163.com";
private String password="obihqyidkcuttfma";
/**
 * 初始化并连接所有的邮件服务器
 * @throws MessagingException 初始化或连接异常
 */
	@Override
	public void connect() throws MessagingException {
		// TODO Auto-generated method stub
	    props = new Properties();  
        //  开启debug调试  
        props.setProperty("mail.debug", "true");  
        // 发送服务器需要身份验证  
        props.setProperty("mail.smtp.auth", "true");  
        //  设置邮件服务器主机名 
        props.setProperty("mail.host", "smtp.163.com");  
        //发送邮件协议名称  
        props.setProperty("mail.transport.protocol", "smtp");  
          

	}
    /**
     * 发送单封邮件
     * @param recipient 收件人邮箱地址
     * @param subject 邮件主题
     * @param content 邮件正文
     * @throws MessagingException 发送邮件错误
     */
	@Override
	public void send(String recipient, String subject, Object content) throws MessagingException {
		// TODO Auto-generated method stub
		  // 创建Session实例对象  
		    Session session = Session.getDefaultInstance(props);
	        Message msg = new MimeMessage(session);  
	        msg.setFrom(new InternetAddress(user));
	        msg.setText((String) content);
	        msg.setRecipient(MimeMessage.RecipientType.TO, new InternetAddress(recipient));
	        msg.setSubject(subject);
	        msg.saveChanges();
	        Transport transport = session.getTransport();
	        transport.connect(user, password);
	        transport.sendMessage(msg, msg.getAllRecipients());
	}
	   /**
     * 询问服务器是否有新邮件到达
     * @return 布朗值，指示是否有新邮件
     * @throws MessagingException 询问服务器出错
     */
	@Override
	public boolean listen() throws MessagingException {
		// TODO Auto-generated method stub

        Session session = Session.getInstance(props);
        IMAPStore store = (IMAPStore) session.getStore("imap");
        store.connect("imap.163.com",user,password);
        // 获得收件箱  
        IMAPFolder folder = (IMAPFolder) store.getFolder("Inbox");
        /* Folder.READ_ONLY：只读权限 
         * Folder.READ_WRITE：可读可写（可以修改邮件的状态） 
         */  
        folder.open(Folder.READ_WRITE); //打开收件箱  

        if (folder.getNewMessageCount() >0)
                  return true;
         //释放资源
            folder.close(true);
            store.close();
   
		return false;
	}
	   /**
     * 接收自动回复的内容，并转换为字符串
     * 注：用你能想到的任意方法寻找回复邮件均可，并不一定要用到这两个参数
     * @param sender 自动回复的发件人邮箱地址
     * @param subject 自动回复的主题
     * @return 自动回复的内容字符串
     * @throws MessagingException 查询邮件异常
     * @throws IOException 下载邮件异常
     */
	@Override
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
		// TODO Auto-generated method stub
		Session session = Session.getInstance(props);

        IMAPStore st = (IMAPStore) session.getStore("imap");

        st.connect("imap.163.com", user, password);

        IMAPFolder fd = (IMAPFolder) st.getFolder("INBOX");

        fd.open(Folder.READ_WRITE);
    
        Message[] msgs = fd.getMessages();

        Message msg = msgs[msgs.length - 1];
        if (msgs == null || msgs.length < 1)   
            throw new MessagingException("未找到要解析的邮件!");  
       System.out.println( "主题"+"subject= MimeUtility.decodeText(msg.getSubject())");
       System.out.println( "发件人"+"sender=getFrom(msg)");
        return (String)msg.getContent();
	
	}
	   /** 
     * 获得邮件发件人 
     * @param msg 邮件内容 
     * @return 解码后的邮件主题 
     */  
	 public static String getFrom(Message msg) throws MessagingException, UnsupportedEncodingException {  
	        String from = "";  
	        Address[] froms = msg.getFrom();  
	        if (froms.length < 1)  
	            throw new MessagingException("没有发件人!");  
	          
	        InternetAddress address = (InternetAddress) froms[0];  
	        String person = address.getPersonal();  
	        if (person != null) {  
	            person = MimeUtility.decodeText(person) + " ";  
	        } else {  
	            person = "";  
	        }  
	        from = person + "<" + address.getAddress() + ">";  
	          
	        return from;  
	    }  

}
